---
name: "⭐ Submit a feature request"
about: 'Feature requests are considered based on team''s capacity '
title: ''
labels: ''
assignees: ''

---

### Describe the feature or problem you’d like to solve

A clear and concise description of what the feature or problem is. If this is a bug report, please use the bug report template instead.

### Proposed solution

How will it benefit Desktop and its users?

### Additional context

Add any other context like screenshots or mockups are helpful, if applicable.
